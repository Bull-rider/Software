#!/bin/sh
echo "uncompress start"
#这里直接就设置固定的目录结构了，如果想自己设置可以取消下面的注释，然后把
if [ $# != 4 ];
then
    echo "you must input the install place and toolchains, eg: ./uncompress.sh `pwd` ../source /root/openssh mipsel-linux"
	exit 1
fi
#压缩包和解压的目录
tarplace=$1
srcplace=$2

#安装和工具目录
installplace=$3
toolchains=$4

echo "tarplace is $tarplace"
echo "srcplace is  $srcplace"
echo "installplace is  $installplace"
echo "toolchains is  $toolchains"
#查找当前文件中所有的压缩包
for tarfile in `find $tarplace -name "*.gz" -o -name "*.bz2"`;do
	echo "====================================================="
	echo "====================================================="
	echo "====================================================="
#解压到指定的目录下
	echo "tarfile:$tarfile"
	tar -zxvf $tarfile -C $srcplace
#获取文件名openssl-1.0.2r.tar.gz
	filename=${tarfile##*/}
#从文件名openssl-1.0.2r.tar.gz中提取出解压后的目录openssl-1.0.2r
	dstpath=`echo $filename | sed 's#\(^.*\)\.tar.*$#\1#g'`
	echo "dstpath:$dstpath"
#copy startWork.sh to source dir to compile
	set -x
#从文件名openssl-1.0.2r中提取出关键字openssl，用于复制对应的startWork.sh-openssl到解压后的目录openssl-1.0.2r下
	key=`echo $dstpath | awk -F"-" '{print $1}'`
	echo "key:$key"
	cp startWork.sh-$key $srcplace/$key*

	cd -
	set +x
	echo "*******************************************************"
	echo "*******************************************************"
	echo "*******************************************************"
	done
																					echo "wait 3s"
sleep 3

#run startWOrk.sh
#编译zlib
cd $srcplace/zlib*
./startWork.sh-zlib $installplace $toolchains
cd -

#编译openssl
cd $srcplace/openssl*
./startWork.sh-openssl $installplace $toolchains
cd -

#编译openssh
cd $srcplace/openssh*
./startWork.sh-openssh $installplace $toolchains
cd -

echo "finished"

