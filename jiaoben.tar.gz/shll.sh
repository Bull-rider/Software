#!/bin/bash
#执行脚本进入到指定的目录
cd /home/yxg/ControlCenter
cur_dir=$(pwd)
echo $cur_dir
make
test_dir=$cur_dir/test
echo $test_dir
cd $test_dir
make

