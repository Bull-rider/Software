#!/bin/bash

cur_dir=$(pwd)
echo $cur_dir

function compile(){
	project_name=ControlCenter
	project_dir=$cur_dir/$project_name
	project_src=$project_dir/src
	project_lib=$project_dir/lib/lib
	project_inc=$project_dir/inc $project_dir/lib/include
	project_target=$project_dir/bin/project_name

	echo "begin compile"
	echo $project_dir
	echo $project_src
	echo $project_lib
	echo $project_inc
	echo $project_target

	#src目录下的所有.c文件的名称存放到项目根目录/src/sources.list文件中
	#先判断文件是否存在,存在就删除
	rm -rf $project/sources.list
	find $project_src -name '*.c' > $project_src/sources.list
	echo "c sources file"
	echo $project_src/sources.list
	
	#创建目标文件,先做删除操作
	rm -rf $project_target
	mkdir $project_target

	#将所有的依赖文件文件的绝对路径记录下来到lib.list文件中
	rm -rf $project_lib/lib.list
	find $project_lib -name '*.so' > $project_lib/lib.list
	echo ".so sources file"
	echo $project_lib/lib.list
	#添加当前目录
	cpvar=.:
	while read line
	do
		echo $line
		cpvar=${cpvar}${project_lib}"/"${line##*/}":"
		echo $cpvar
	done < $project_lib/lib.list

	echo "print cpvar"
	echo $cpvar
	#删除中间文件
	rm -rf $project_lib/lib.list
	lenght=${#cpvar}-1
	cpvar=${cpvar:0:length}
	echo $cpvar
	arm-linux-gcc -o $project_target -sourcepath $project_src @$project_src/sources.list -I $projcet_inc -L $project_lib
	rm -rf $project_src/sources.list

	cd $project_target
	chmod a+x $project_target/${project_name}.exe

	cp -r $project_lib $project_target/lib
}
compile
exit 0

