#!/bin/sh

if [ $# != 2 ];
then
    echo "you must input the install place and toolchains, eg. ./startWork.sh /tmp mipsel-linux"
	exit 1
fi

place=$1
toolchains=$2

echo "place is $place, toolchains is  $toolchains"

#先配置，生成Makefile
./configure --prefix=$place

#修改Makefile，将工具链修改为交叉编译后的工具链
cat Makefile | sed "s/CC=gcc/CC=$toolchains-gcc/g" | sed "s/AR=ar/AR=$toolchains-ar/g" | sed "s/CPP=gcc -E/CPP=$toolchains-gcc -E/g" | sed "s/LDSHARED=gcc/LDSHARED=$toolchains-gcc/g" > Makefile.tmp

#生成patch文件
diff -Nura Makefile Makefile.tmp > ./Makefile.patch

#应用patch，修改原Makefile文件
patch -p0 < ./Makefile.patch

make
make install
