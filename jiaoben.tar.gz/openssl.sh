#!/bin/sh

if [ $# != 2 ];
then
    echo "you must input the install place and toolchains, eg. ./startWork.sh /tmp mipsel-linux"
	exit 1
fi

place=$1
toolchains=$2

echo "place is $place, toolchains is  $toolchains"

./Configure --prefix=$place os/compiler:$toolchains-gcc

make
make install
